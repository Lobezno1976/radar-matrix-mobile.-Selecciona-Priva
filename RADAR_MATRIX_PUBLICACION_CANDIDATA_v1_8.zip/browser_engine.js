(function(g){'use strict';
const alias={'atlético':'at madrid','atletico':'at madrid','athletic':'ath bilbao','real sociedad':'sociedad','deportivo':'deportivo','racing':'racing','alavés':'alaves','málaga':'malaga'};
function norm(s){let n=String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();return alias[n]||n;}
function date(s){if(/^\d{4}-\d\d-\d\d$/.test(s))return s;let m=String(s).match(/^(\d\d?)\/(\d\d?)\/(\d{4})$/);return m?`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`:null;}
function num(s){if(s===null||s===undefined||String(s).trim()==='')return null;let n=Number(s);return Number.isFinite(n)&&n>=0?n:null;}
function event(row,leg,home,away){let m=leg.match(/^(.+?) (\+\d+,\d+ (?:tarjetas|tiros a puerta|tiros|córners|goles)|no pierde por 3\+)$/);if(!m)return null;let side=norm(m[1])===norm(home)?'H':norm(m[1])===norm(away)?'A':null;if(!side)return null;
let f=side==='H'?'H':'A',opp=side==='H'?'A':'H',market=m[2],key;
if(market==='no pierde por 3+'){let a=num(row[f==='H'?'FTHG':'FTAG']),b=num(row[opp==='H'?'FTHG':'FTAG']);return a===null||b===null?null:a-b>-3;}
if(market.includes('tiros a puerta'))key=f==='H'?'HST':'AST';else if(market.includes('tiros'))key=f==='H'?'HS':'AS';else if(market.includes('tarjetas'))key=f==='H'?'HY':'AY';else if(market.includes('córners'))key=f==='H'?'HC':'AC';else if(market.includes('goles'))key=f==='H'?'FTHG':'FTAG';else return null;
let n=num(row[key]);return n===null?null:n>Number(market.match(/\+(\d+,\d+)/)[1].replace(',','.'));}
let historical=null;
async function load(){if(historical)return historical;let response=await fetch('./historical_stats.csv');if(!response.ok)throw Error('Histórico HTTP '+response.status);let text=await response.text();historical=RadarMobileSources.csv(text).map(r=>({...r,Date:date(r.Date)})).filter(r=>r.Date);return historical;}
function select(rows,home,away,legs,cutoff){let contexts=[rows.filter(r=>r.Date<cutoff&&norm(r.HomeTeam)===norm(home)),rows.filter(r=>r.Date<cutoff&&norm(r.AwayTeam)===norm(away))];let split=contexts.map(rs=>{rs.sort((a,b)=>a.Date.localeCompare(b.Date));let k=Math.floor(rs.length*.8);return [rs.slice(0,k),rs.slice(k)];});
if(split.some(s=>s[0].length<15||s[1].length<5))return {status:'INSUFFICIENT_TEAM_SAMPLE',counts:split.map(s=>({train:s[0].length,holdout:s[1].length}))};
// Require identical denominators for all candidate legs in each context.
let all=split.map(([train,test])=>[train,test].map(rs=>rs.filter(r=>legs.every(l=>{let t=norm(l.slice(0,l.indexOf(' +')>0?l.indexOf(' +'):l.indexOf(' no pierde')));return t===norm(home)||t===norm(away);}))));
if(all.some(s=>s[0].length<15||s[1].length<5))return {status:'INSUFFICIENT_COMPLETE_CASES',counts:all.map(s=>({train:s[0].length,holdout:s[1].length}))};
let evaluate=(chosen,part)=>all.map((s,context)=>{let rr=s[part],hits=rr.filter(r=>chosen.every(i=>{let leg=legs[i],target=norm(leg.slice(0,leg.indexOf(' +')>0?leg.indexOf(' +'):leg.indexOf(' no pierde')));if(target!==norm(context===0?home:away))return true;return event(r,leg,home,away)===true;})).length;return {hits,n:rr.length,pct:Math.round(10000*hits/rr.length)/100};});
let rank=ids=>{let rates=evaluate(ids,0).map(x=>x.hits/x.n);return [Math.min(...rates),rates[0]+rates[1]]};
// Beam over the 6 legs from the frozen J9 matrix, not a 139-market optimizer.
let beam=[[]],width=100;
for(let depth=1;depth<=6;depth++){let next=[];for(let seq of beam){for(let i=0;i<legs.length;i++){if(seq.includes(i))continue;let candidate=[...seq,i];let r=rank(candidate);next.push({candidate,r});}}next.sort((a,b)=>b.r[0]-a.r[0]||b.r[1]-a.r[1]||a.candidate.join(',').localeCompare(b.candidate.join(',')));beam=next.slice(0,width).map(x=>x.candidate);}
let chosen=beam[0],variants=[3,4,5,6].map((n,i)=>({name:['CORE','SAT1','SAT2','SAT3'][i],legs:chosen.slice(0,n).map(j=>legs[j]),train_by_context:evaluate(chosen.slice(0,n),0),holdout_by_context:evaluate(chosen.slice(0,n),1)}));return {status:'BROWSER_J9_SIX_LEG_BEAM',home,away,cutoff_exclusive:cutoff,candidate_count:legs.length,variants,nested:true,counts:all.map(s=>({train:s[0].length,holdout:s[1].length})),calibrated:false,match_joint_probability:null,source:'bundled historical_stats.csv',new_provider_rows_used:false};}
g.RadarBrowserEngine={load,select,event,norm,date};})(window);
