# RADAR Matrix — candidato de publicación estática

Origen: v1.8, sin código Python ni carpetas de auditoría. No se ha publicado ni probado en Android.

**Advertencia:** los ficheros historical_stats.csv y j9_historico.csv contienen datos históricos y pasan a ser públicamente descargables al publicar. Revisar procedencia, licencia y contenido antes de hacer público el repositorio.

La versión v1.9 no estaba disponible en la biblioteca al preparar este paquete. No se afirma que el seguimiento v1.9 esté incorporado.

No hay pruebas de conectividad real con proveedores ni de ejecución en Android.
